/* ================================================
   LUMA HERITAGE — luma.js v2.0
   Shared JS: header scroll, mobile menu,
   active nav, FAQ accordion, counter animation,
   scroll reveal, contact form handler
   ================================================ */

(function () {
  'use strict';

  /* ── HEADER SCROLL EFFECT ── */
  const header = document.querySelector('.header');
  if (header) {
    const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ── HERO KEN-BURNS ── */
  const hero = document.querySelector('.hero');
  if (hero) {
    requestAnimationFrame(() => setTimeout(() => hero.classList.add('loaded'), 100));
  }

  /* ── MOBILE MENU ── */
  const toggle = document.getElementById('menuToggle');
  const menu   = document.getElementById('menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('active');
      menu.classList.toggle('active');
      document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
    });
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      toggle.classList.remove('active');
      menu.classList.remove('active');
      document.body.style.overflow = '';
    }));
    document.addEventListener('click', e => {
      if (!menu.contains(e.target) && !toggle.contains(e.target)) {
        toggle.classList.remove('active');
        menu.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }

  /* ── ACTIVE NAV LINK ── */
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.menu a').forEach(a => {
    const href = a.getAttribute('href') || '';
    const page = href.split('#')[0].split('/').pop();
    if (page === currentPage || (currentPage === '' && page === 'index.html')) {
      a.classList.add('active');
    }
  });

  /* ── FAQ ACCORDION ── */
  document.querySelectorAll('.faq-item').forEach(item => {
    const btn    = item.querySelector('.faq-question');
    const answer = item.querySelector('.faq-answer');
    if (!btn || !answer) return;
    btn.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      // close all
      document.querySelectorAll('.faq-item.open').forEach(o => {
        o.classList.remove('open');
        o.querySelector('.faq-answer').style.maxHeight = null;
      });
      if (!isOpen) {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });

  /* ── COUNTER ANIMATION ── */
  function animateCounter(el) {
    const raw  = el.textContent.trim();
    const plus = raw.includes('+');
    const num  = parseInt(raw.replace(/\D/g, ''), 10);
    if (isNaN(num)) return;
    const dur  = 1800;
    const step = 16;
    const inc  = num / (dur / step);
    let cur = 0;
    const tick = () => {
      cur = Math.min(cur + inc, num);
      el.textContent = Math.ceil(cur) + (plus ? '+' : '');
      if (cur < num) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  const counterObs = new IntersectionObserver((entries, obs) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const h3 = e.target.querySelector('h3');
      if (h3) animateCounter(h3);
      obs.unobserve(e.target);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('.number-item').forEach(el => counterObs.observe(el));

  /* ── SCROLL REVEAL ── */
  const revealObs = new IntersectionObserver((entries, obs) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      e.target.classList.add('visible');
      obs.unobserve(e.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

  /* ── CONTACT FORM (simulated) ── */
  const form = document.querySelector('.contact-form form, form.contact-form');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      if (btn) {
        btn.textContent = 'Sending…';
        btn.disabled = true;
      }
      await new Promise(r => setTimeout(r, 1200));
      const success = form.querySelector('.form-success');
      if (success) {
        form.querySelectorAll('.form-grid, input, textarea, button').forEach(el => el.style.display = 'none');
        success.style.display = 'block';
      } else {
        if (btn) { btn.textContent = '✓ Message Sent'; btn.style.background = '#1ebe57'; }
      }
    });
  }

})();
